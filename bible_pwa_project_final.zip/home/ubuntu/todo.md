## Tareas Pendientes

- [ ] **Fase 1: Investigar YouVersion y planificar la PWA**
  - [x] Investigar las características de YouVersion y las funcionalidades de una PWA de la Biblia.
  - [x] Definir las funcionalidades clave para la PWA de la Biblia.
  - [x] Identificar posibles fuentes de datos bíblicos (APIs).

- [ ] **Fase 2: Buscar y configurar datos bíblicos**
  - [x] Seleccionar una API o fuente de datos bíblicos.
  - [x] Configurar el acceso a los datos.
  - [x] Estructurar los datos para su uso en la aplicación.

- [ ] **Fase 3: Desarrollar la aplicación web progresiva**
  - [ ] Inicializar el proyecto PWA (React).

- [ ] **Fase 3: Desarrollar la aplicación web progresiva**
  - [x] Inicializar el proyecto PWA (React).
  - [x] Implementar la visualización del texto bíblico.
  - [x] Implementar la navegación (libros, capítulos, versículos).
  - [x] Implementar la funcionalidad de búsqueda básica.
  - [x] Configurar el Service Worker para capacidades offline.
  - [x] Crear el Web App Manifest para la instalabilidad.

- [ ] **Fase 4: Probar la aplicación localmente**
  - [x] Ejecutar la aplicación localmente.
  - [x] Verificar la funcionalidad principal.
  - [x] Probar las capacidades offline e instalabilidad.

- [ ] **Fase 5: Desplegar la PWA en producción**
  - [x] Desplegar la aplicación en un entorno de producción.
  - [x] Verificar el despliegue y la accesibilidad pública.

