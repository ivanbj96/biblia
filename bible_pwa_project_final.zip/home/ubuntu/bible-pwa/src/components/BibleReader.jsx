import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Loader2, Search, Book, ChevronLeft, ChevronRight } from 'lucide-react';
import { getBibles, getBooks, getChapters, getChapterContent, searchBible, getVerseOfTheDay } from '../services/bibleApi';

const BibleReader = () => {
  const [bibles, setBibles] = useState([]);
  const [selectedBible, setSelectedBible] = useState('');
  const [books, setBooks] = useState([]);
  const [selectedBook, setSelectedBook] = useState('');
  const [chapters, setChapters] = useState([]);
  const [selectedChapter, setSelectedChapter] = useState('');
  const [chapterContent, setChapterContent] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [verseOfTheDay, setVerseOfTheDay] = useState(null);
  const [loading, setLoading] = useState(false);
  const [currentView, setCurrentView] = useState('home'); // 'home', 'reader', 'search'

  // Cargar Biblias al inicializar
  useEffect(() => {
    const loadBibles = async () => {
      try {
        setLoading(true);
        const biblesData = await getBibles();
        setBibles(biblesData);
        // Seleccionar la primera Biblia en español si está disponible
        const spanishBible = biblesData.find(bible => 
          bible.language.name.toLowerCase().includes('spanish') || 
          bible.language.name.toLowerCase().includes('español')
        ) || biblesData[0];
        if (spanishBible) {
          setSelectedBible(spanishBible.id);
        }
      } catch (error) {
        console.error('Error loading bibles:', error);
      } finally {
        setLoading(false);
      }
    };
    loadBibles();
  }, []);

  // Cargar libros cuando se selecciona una Biblia
  useEffect(() => {
    if (selectedBible) {
      const loadBooks = async () => {
        try {
          setLoading(true);
          const booksData = await getBooks(selectedBible);
          setBooks(booksData);
          // Cargar versículo del día
          const votd = await getVerseOfTheDay(selectedBible);
          setVerseOfTheDay(votd);
        } catch (error) {
          console.error('Error loading books:', error);
        } finally {
          setLoading(false);
        }
      };
      loadBooks();
    }
  }, [selectedBible]);

  // Cargar capítulos cuando se selecciona un libro
  useEffect(() => {
    if (selectedBible && selectedBook) {
      const loadChapters = async () => {
        try {
          setLoading(true);
          const chaptersData = await getChapters(selectedBible, selectedBook);
          setChapters(chaptersData);
        } catch (error) {
          console.error('Error loading chapters:', error);
        } finally {
          setLoading(false);
        }
      };
      loadChapters();
    }
  }, [selectedBible, selectedBook]);

  // Cargar contenido del capítulo cuando se selecciona un capítulo
  useEffect(() => {
    if (selectedBible && selectedChapter) {
      const loadChapterContent = async () => {
        try {
          setLoading(true);
          const content = await getChapterContent(selectedBible, selectedChapter);
          setChapterContent(content.content);
          setCurrentView('reader');
        } catch (error) {
          console.error('Error loading chapter content:', error);
        } finally {
          setLoading(false);
        }
      };
      loadChapterContent();
    }
  }, [selectedBible, selectedChapter]);

  const handleSearch = async () => {
    if (!searchQuery.trim() || !selectedBible) return;
    
    try {
      setLoading(true);
      const results = await searchBible(selectedBible, searchQuery);
      setSearchResults(results.verses || []);
      setCurrentView('search');
    } catch (error) {
      console.error('Error searching:', error);
    } finally {
      setLoading(false);
    }
  };

  const navigateChapter = (direction) => {
    const currentIndex = chapters.findIndex(ch => ch.id === selectedChapter);
    if (direction === 'prev' && currentIndex > 0) {
      setSelectedChapter(chapters[currentIndex - 1].id);
    } else if (direction === 'next' && currentIndex < chapters.length - 1) {
      setSelectedChapter(chapters[currentIndex + 1].id);
    }
  };

  const renderHome = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Book className="h-5 w-5" />
            Versículo del Día
          </CardTitle>
        </CardHeader>
        <CardContent>
          {verseOfTheDay ? (
            <div className="text-lg italic text-center p-4 bg-muted rounded-lg">
              {verseOfTheDay.content}
              <div className="text-sm text-muted-foreground mt-2">
                {verseOfTheDay.reference}
              </div>
            </div>
          ) : (
            <div className="text-center text-muted-foreground">
              Cargando versículo del día...
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Comenzar a Leer</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium">Seleccionar Biblia:</label>
            <Select value={selectedBible} onValueChange={setSelectedBible}>
              <SelectTrigger>
                <SelectValue placeholder="Selecciona una Biblia" />
              </SelectTrigger>
              <SelectContent>
                {bibles.map(bible => (
                  <SelectItem key={bible.id} value={bible.id}>
                    {bible.name} ({bible.language.name})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium">Seleccionar Libro:</label>
            <Select value={selectedBook} onValueChange={setSelectedBook}>
              <SelectTrigger>
                <SelectValue placeholder="Selecciona un libro" />
              </SelectTrigger>
              <SelectContent>
                {books.map(book => (
                  <SelectItem key={book.id} value={book.id}>
                    {book.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium">Seleccionar Capítulo:</label>
            <Select value={selectedChapter} onValueChange={setSelectedChapter}>
              <SelectTrigger>
                <SelectValue placeholder="Selecciona un capítulo" />
              </SelectTrigger>
              <SelectContent>
                {chapters.map(chapter => (
                  <SelectItem key={chapter.id} value={chapter.id}>
                    {chapter.number}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderReader = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Button variant="outline" onClick={() => setCurrentView('home')}>
          Volver al Inicio
        </Button>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => navigateChapter('prev')}
            disabled={chapters.findIndex(ch => ch.id === selectedChapter) === 0}
          >
            <ChevronLeft className="h-4 w-4" />
            Anterior
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => navigateChapter('next')}
            disabled={chapters.findIndex(ch => ch.id === selectedChapter) === chapters.length - 1}
          >
            Siguiente
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-6">
          <div 
            className="prose prose-lg max-w-none leading-relaxed"
            dangerouslySetInnerHTML={{ __html: chapterContent }}
          />
        </CardContent>
      </Card>
    </div>
  );

  const renderSearch = () => (
    <div className="space-y-4">
      <Button variant="outline" onClick={() => setCurrentView('home')}>
        Volver al Inicio
      </Button>
      
      <Card>
        <CardHeader>
          <CardTitle>Resultados de Búsqueda</CardTitle>
        </CardHeader>
        <CardContent>
          {searchResults.length > 0 ? (
            <div className="space-y-4">
              {searchResults.map((result, index) => (
                <div key={index} className="p-4 border rounded-lg">
                  <div className="font-medium text-sm text-muted-foreground mb-2">
                    {result.reference}
                  </div>
                  <div dangerouslySetInnerHTML={{ __html: result.text }} />
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center text-muted-foreground">
              No se encontraron resultados para "{searchQuery}"
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold">Biblia PWA</h1>
            <div className="flex items-center gap-2">
              <Input
                placeholder="Buscar en la Biblia..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                className="w-64"
              />
              <Button onClick={handleSearch} disabled={!selectedBible || loading}>
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        {loading && currentView === 'home' ? (
          <div className="flex items-center justify-center h-64">
            <Loader2 className="h-8 w-8 animate-spin" />
          </div>
        ) : (
          <>
            {currentView === 'home' && renderHome()}
            {currentView === 'reader' && renderReader()}
            {currentView === 'search' && renderSearch()}
          </>
        )}
      </main>
    </div>
  );
};

export default BibleReader;

